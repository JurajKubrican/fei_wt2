<?php

if (!defined('APP_VALID'))
  die;


require_once 'controller/JDB.php';
require_once 'controller/apiController.php';
//require_once 'controller/AISConnect.php';

//require_once '../vendor/autoload.php';





//require_once 'model/User.php';
//require_once 'model/Type.php';
//require_once 'model/Absence.php';



